"""Neural network building blocks."""
