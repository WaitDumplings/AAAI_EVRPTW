"""Legacy Gurobi VRPTW benchmark."""
