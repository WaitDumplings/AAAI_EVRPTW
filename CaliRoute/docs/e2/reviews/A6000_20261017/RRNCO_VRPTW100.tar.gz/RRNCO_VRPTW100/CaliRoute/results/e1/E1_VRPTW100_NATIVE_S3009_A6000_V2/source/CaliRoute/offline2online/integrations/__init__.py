"""External project integration helpers."""
