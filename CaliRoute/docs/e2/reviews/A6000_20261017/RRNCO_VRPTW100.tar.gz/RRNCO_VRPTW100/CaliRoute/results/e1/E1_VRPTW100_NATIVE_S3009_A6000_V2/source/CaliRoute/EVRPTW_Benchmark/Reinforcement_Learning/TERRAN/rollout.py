from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
import sys
import time
from typing import Any, Sequence

import numpy as np
import torch

REPO_ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(REPO_ROOT / "EVRPTW_Core"))

from evrptw_core.schema import merge_route_sequences


# Instance arrays are invariant between reset and termination. The caller owns
# this cache and must discard it when environments reset or instances change.
STATIC_OBSERVATION_KEYS = frozenset({
    "cus_loc", "depot_loc", "rs_loc", "demand", "time_window", "service_time",
    "edge_distance", "edge_time", "edge_energy", "battery_capacity", "loading_capacity",
    "full_charge_time", "fixed_full_charge", "instance_mask",
    "node_input_context", "graph_input_context",
})


def stack_observations(observations: Sequence[dict[str, np.ndarray]], static_cache=None) -> dict[str, np.ndarray]:
    output = {}
    for key in observations[0]:
        if static_cache is not None and key in STATIC_OBSERVATION_KEYS:
            if key not in static_cache:
                static_cache[key] = np.stack([obs[key] for obs in observations], axis=0)
            output[key] = static_cache[key]
        else:
            output[key] = np.stack([obs[key] for obs in observations], axis=0)
    return output


def tensor_from_array(value: Any, device: str | torch.device) -> torch.Tensor:
    if isinstance(value, torch.Tensor):
        return value.to(device)
    return torch.as_tensor(np.asarray(value), device=device)


def _sync_cuda(device: str | torch.device) -> None:
    if torch.cuda.is_available() and str(device).startswith("cuda"):
        torch.cuda.synchronize()


@torch.no_grad()
def encode_static_rollout(agent, obs_batch: dict[str, np.ndarray]):
    """Cache only backbones that explicitly guarantee static, deterministic encoding.

    The caller owns this cache for one rollout, discards it at reset, and must
    never pass it to a gradient-bearing policy update. Legacy encoders with
    training-time dropout stay on the original full-forward path.
    """
    if not getattr(agent.backbone, "supports_static_rollout_cache", False):
        return None
    return agent.backbone.encode(obs_batch)


def sample_actions(
    agent,
    obs_batch: dict[str, np.ndarray],
    decode_mode: str,
    device: str | torch.device,
    cached_embeddings=None,
):
    logits_tuple = (
        agent.backbone(obs_batch)
        if cached_embeddings is None
        else agent.backbone.decode(obs_batch, cached_embeddings)
    )
    logits = logits_tuple[0]
    dist = torch.distributions.Categorical(logits=logits)
    if decode_mode == "greedy":
        actions = torch.argmax(logits, dim=-1)
    elif decode_mode == "sample":
        actions = dist.sample()
    else:
        raise ValueError(f"Unknown decode_mode={decode_mode!r}")
    logprob = dist.log_prob(actions)
    entropy = dist.entropy()
    value = agent.critic((logits_tuple[0], logits_tuple[1])).squeeze(-1)
    return actions, logprob, entropy, value, logits


@dataclass
class RolloutBatch:
    observations: list[dict[str, np.ndarray]]
    actions: torch.Tensor
    old_logprobs: torch.Tensor
    rewards: torch.Tensor
    dones: torch.Tensor
    route_boundaries: torch.Tensor
    values: torch.Tensor
    valid: torch.Tensor
    entropies: torch.Tensor
    final_infos: list[dict[str, Any]]
    timings: dict[str, float]
    instance_ids: list[str] | None = None
    expert_actions: torch.Tensor | None = None
    expert_valid: torch.Tensor | None = None
    expert_advantages: torch.Tensor | None = None
    bootstrap_values: torch.Tensor | None = None
    reward_component_stats: dict[str, dict[str, float]] | None = None
    initial_shaping_potential: torch.Tensor | None = None


def reset_envs(envs, seed: int | None = None):
    observations = []
    infos = []
    for idx, env in enumerate(envs):
        kwargs = {}
        if seed is not None:
            kwargs["seed"] = int(seed) + idx
        obs, info = env.reset(**kwargs)
        observations.append(obs)
        infos.append(info)
    return observations, infos


def current_instance_ids(envs) -> list[str]:
    out = []
    for env in envs:
        instance = getattr(env.unwrapped, "instance", None)
        out.append(str(getattr(instance, "instance_id", "")))
    return out


def route_boundaries_from_actions(
    actions: np.ndarray,
    valid: np.ndarray,
    current_route_customer_count: np.ndarray,
    num_customers: int,
) -> np.ndarray:
    """Flag depot actions that close a non-empty route, aligned to action/reward time."""
    action_arr = np.asarray(actions, dtype=np.int64)
    valid_arr = np.asarray(valid, dtype=bool)
    boundaries = (action_arr == 0) & valid_arr & (current_route_customer_count > 0)
    customer = (action_arr >= 1) & (action_arr <= int(num_customers)) & valid_arr
    current_route_customer_count[customer] += 1
    current_route_customer_count[boundaries] = 0
    return boundaries


def step_envs(envs, actions: np.ndarray):
    observations, rewards, dones, infos = [], [], [], []
    for env, action in zip(envs, actions):
        obs, reward, terminated, truncated, info = env.step(action)
        observations.append(obs)
        rewards.append(reward)
        dones.append(np.asarray(terminated, dtype=bool) | np.asarray(truncated, dtype=bool))
        infos.append(info)
    return observations, np.asarray(rewards, dtype=np.float32), np.asarray(dones, dtype=bool), infos


def _accumulate_reward_component_stats(stats, infos, rewards, valid):
    """Accumulate physical/shaping diagnostics over valid actions only."""
    for index, info in enumerate(infos):
        terms = dict(info.get("reward_components", {}))
        terms.setdefault("base", np.asarray(rewards[index]))
        terms.setdefault("shaped", np.asarray(rewards[index]))
        terms["shaping"] = np.asarray(info.get("reward_shaping", terms["shaped"] - terms["base"]))
        if "reward_failure_cost" in info:
            terms["failure_cost"] = np.asarray(info["reward_failure_cost"])
        for name, values in terms.items():
            if name == "pbrs_scale":
                continue  # A coefficient is not a reward component.
            values = np.broadcast_to(np.asarray(values, dtype=np.float64), valid[index].shape)[valid[index]]
            finite = np.isfinite(values)
            current = stats.setdefault(name, {"sum": 0., "sum_abs": 0., "sum_sq": 0., "count": 0., "max_abs": 0., "nonfinite_count": 0.})
            current["nonfinite_count"] += float((~finite).sum())
            values = values[finite]
            if values.size:
                current["sum"] += float(values.sum())
                current["sum_abs"] += float(np.abs(values).sum())
                current["sum_sq"] += float(np.square(values).sum())
                current["count"] += float(values.size)
                current["max_abs"] = max(current["max_abs"], float(np.abs(values).max()))


def collect_rollout(
    agent,
    envs,
    rollout_steps: int,
    decode_mode: str,
    device: str | torch.device,
    seed: int | None = None,
    profile_timing: bool = False,
    expert_provider=None,
    bootstrap_truncation: bool = False,
) -> RolloutBatch:
    total_start = time.perf_counter()
    reset_start = time.perf_counter()
    observations, infos = reset_envs(envs, seed=seed)
    reset_time_s = time.perf_counter() - reset_start
    instance_ids = current_instance_ids(envs)
    done = np.zeros((len(envs), envs[0].unwrapped.n_traj), dtype=bool)
    initial_shaping_potential = tensor_from_array(np.stack([
        np.asarray(info.get("reward_shaping_initial_potential", np.zeros(env.unwrapped.n_traj)), dtype=np.float64)
        for env, info in zip(envs, infos)
    ]), device).float()
    reward_component_stats: dict[str, dict[str, float]] = {}
    obs_steps: list[dict[str, np.ndarray]] = []
    actions_steps = []
    logprob_steps = []
    reward_steps = []
    done_steps = []
    value_steps = []
    valid_steps = []
    entropy_steps = []
    expert_action_steps = []
    expert_valid_steps = []
    model_action_time_s = 0.0
    env_step_time_s = 0.0
    stack_obs_time_s = 0.0
    num_customers = int(getattr(envs[0].unwrapped, "num_customers", 0))
    current_route_customer_count = np.zeros((len(envs), envs[0].unwrapped.n_traj), dtype=np.int32)
    route_boundary_steps = []
    cached_embeddings = None
    static_obs_cache = {} if getattr(agent.backbone, "cache_static_observations", False) else None

    for step in range(int(rollout_steps)):
        valid = ~done
        stack_start = time.perf_counter()
        obs_batch = stack_observations(observations, static_cache=static_obs_cache)
        stack_obs_time_s += time.perf_counter() - stack_start
        if expert_provider is not None:
            expert_actions_np, expert_valid_np = expert_provider.actions_for_batch(
                instance_ids,
                len(obs_steps),
                obs_batch["action_mask"],
                done,
            )
            expert_action_steps.append(tensor_from_array(expert_actions_np, device).long())
            expert_valid_steps.append(tensor_from_array(expert_valid_np, device).bool())
        if profile_timing:
            _sync_cuda(device)
        model_start = time.perf_counter()
        with torch.no_grad():
            if step == 0:
                cached_embeddings = encode_static_rollout(agent, obs_batch)
            actions, logprob, entropy, value, _ = sample_actions(
                agent, obs_batch, decode_mode=decode_mode, device=device,
                cached_embeddings=cached_embeddings,
            )
        if profile_timing:
            _sync_cuda(device)
        model_action_time_s += time.perf_counter() - model_start
        action_np = actions.detach().cpu().numpy().astype(np.int64)
        route_boundary_np = route_boundaries_from_actions(
            action_np,
            valid,
            current_route_customer_count,
            num_customers=num_customers,
        )
        env_start = time.perf_counter()
        next_observations, reward_np, step_done, infos = step_envs(envs, action_np)
        env_step_time_s += time.perf_counter() - env_start
        _accumulate_reward_component_stats(reward_component_stats, infos, reward_np, valid)

        obs_steps.append(obs_batch)
        actions_steps.append(actions.detach())
        logprob_steps.append(logprob.detach())
        entropy_steps.append(entropy.detach())
        reward_steps.append(tensor_from_array(reward_np, device).float())
        done_steps.append(tensor_from_array(step_done, device).bool())
        route_boundary_steps.append(tensor_from_array(route_boundary_np, device).bool())
        value_steps.append(value.detach())
        valid_steps.append(tensor_from_array(valid, device).bool())

        observations = next_observations
        done = done | step_done
        if done.all():
            break

    bootstrap_values = None
    bootstrap_time_s = 0.0
    if bootstrap_truncation and not done.all():
        bootstrap_start = time.perf_counter()
        next_obs_batch = stack_observations(observations, static_cache=static_obs_cache)
        tensor_device = torch.device(device)
        cuda_devices = ([tensor_device.index if tensor_device.index is not None else torch.cuda.current_device()]
                        if tensor_device.type == "cuda" else [])
        # Greedy avoids drawing an action. Fork RNG additionally preserves a
        # legacy backbone's training-time dropout stream on this diagnostic pass.
        with torch.no_grad(), torch.random.fork_rng(devices=cuda_devices):
            _, _, _, next_values, _ = sample_actions(
                agent, next_obs_batch, decode_mode="greedy", device=device,
                cached_embeddings=cached_embeddings,
            )
        unfinished = tensor_from_array(~done, device).bool()
        while unfinished.ndim < next_values.ndim:
            unfinished = unfinished.unsqueeze(-1)
        bootstrap_values = torch.where(unfinished, next_values, torch.zeros_like(next_values)).detach()
        bootstrap_time_s = time.perf_counter() - bootstrap_start
    total_time_s = time.perf_counter() - total_start
    expert_actions = torch.stack(expert_action_steps, dim=0) if expert_action_steps else None
    expert_valid = torch.stack(expert_valid_steps, dim=0) if expert_valid_steps else None
    expert_advantages = None
    if expert_provider is not None and expert_actions is not None:
        expert_advantages = expert_provider.advantages_for_final_infos(
            instance_ids,
            infos,
            len(obs_steps),
            device,
        )
    return RolloutBatch(
        observations=obs_steps,
        actions=torch.stack(actions_steps, dim=0),
        old_logprobs=torch.stack(logprob_steps, dim=0),
        rewards=torch.stack(reward_steps, dim=0),
        dones=torch.stack(done_steps, dim=0),
        route_boundaries=torch.stack(route_boundary_steps, dim=0),
        values=torch.stack(value_steps, dim=0),
        valid=torch.stack(valid_steps, dim=0),
        entropies=torch.stack(entropy_steps, dim=0),
        final_infos=infos,
        timings={
            "rollout_total_time_s": float(total_time_s),
            "rollout_reset_time_s": float(reset_time_s),
            "rollout_stack_obs_time_s": float(stack_obs_time_s),
            "rollout_model_action_time_s": float(model_action_time_s),
            "rollout_env_step_time_s": float(env_step_time_s),
            "rollout_interaction_time_s": float(model_action_time_s + env_step_time_s),
            "rollout_bootstrap_time_s": float(bootstrap_time_s),
        },
        instance_ids=instance_ids,
        expert_actions=expert_actions,
        expert_valid=expert_valid,
        expert_advantages=expert_advantages,
        bootstrap_values=bootstrap_values,
        reward_component_stats=reward_component_stats,
        initial_shaping_potential=initial_shaping_potential,
    )


def compute_returns(rewards: torch.Tensor, dones: torch.Tensor, gamma: float,
                    last_values: torch.Tensor | None = None) -> torch.Tensor:
    returns = torch.zeros_like(rewards)
    running = torch.zeros_like(rewards[0]) if last_values is None else last_values.detach().to(rewards)
    if running.shape != rewards[0].shape:
        raise ValueError("last_values shape must match one reward step")
    for step in reversed(range(rewards.size(0))):
        running = rewards[step] + float(gamma) * running * (~dones[step]).float()
        returns[step] = running
    return returns


def select_best_trajectory(info: dict[str, Any], include_routes: bool = True) -> dict[str, Any]:
    success = np.asarray(info["success"], dtype=bool)
    objective = np.asarray(info["objective_distance_km"], dtype=np.float64)
    served = np.asarray(info["served_customers"], dtype=np.int32)
    if np.any(success):
        candidates = np.where(success)[0]
        selected = int(candidates[np.argmin(objective[candidates])])
        feasible = True
    else:
        max_served = int(served.max()) if served.size else 0
        candidates = np.where(served == max_served)[0]
        selected = int(candidates[np.argmin(objective[candidates])]) if candidates.size else 0
        feasible = False
    row = {
        "selected_traj_idx": selected,
        "feasible": feasible,
        "objective_distance_km": float(objective[selected]),
        "vehicle_count": int(np.asarray(info["vehicle_count"])[selected]),
        "served_customers": int(served[selected]),
    }
    if include_routes and "routes" in info:
        routes = info["routes"][selected]
        route_sequence = merge_route_sequences(routes)
        row["route_sequence_json"] = json.dumps(route_sequence)
        row["routes_json"] = json.dumps(routes)
    return row


def rollout_single_instance(
    agent,
    env,
    decode_mode: str,
    max_steps: int,
    device: str | torch.device,
    seed: int | None = None,
    include_routes: bool = True,
):
    obs, info = env.reset(seed=seed) if seed is not None else env.reset()
    done = np.zeros(env.unwrapped.n_traj, dtype=bool)
    start = time.perf_counter()
    cached_embeddings = None
    for step in range(int(max_steps)):
        obs_batch = stack_observations([obs])
        with torch.no_grad():
            if step == 0:
                cached_embeddings = encode_static_rollout(agent, obs_batch)
            actions, _, _, _, _ = sample_actions(
                agent, obs_batch, decode_mode=decode_mode, device=device,
                cached_embeddings=cached_embeddings,
            )
        obs, reward, terminated, truncated, info = env.step(actions.squeeze(0).detach().cpu().numpy().astype(np.int64))
        done = done | np.asarray(terminated, dtype=bool) | np.asarray(truncated, dtype=bool)
        if done.all():
            break
    elapsed = time.perf_counter() - start
    row = select_best_trajectory(info, include_routes=include_routes)
    row["runtime_s"] = float(elapsed)
    return row


def rollout_eval_batch(
    agent,
    envs,
    decode_mode: str,
    max_steps: int,
    device: str | torch.device,
    seed: int | None = None,
    include_routes: bool = False,
):
    if not envs:
        return []
    observations, infos = reset_envs(envs, seed=seed)
    n_traj = int(envs[0].unwrapped.n_traj)
    done = np.zeros((len(envs), n_traj), dtype=bool)
    start = time.perf_counter()
    cached_embeddings = None
    for step in range(int(max_steps)):
        obs_batch = stack_observations(observations)
        with torch.no_grad():
            if step == 0:
                cached_embeddings = encode_static_rollout(agent, obs_batch)
            actions, _, _, _, _ = sample_actions(
                agent, obs_batch, decode_mode=decode_mode, device=device,
                cached_embeddings=cached_embeddings,
            )
        action_np = actions.detach().cpu().numpy().astype(np.int64)
        observations, _, step_done, infos = step_envs(envs, action_np)
        done = done | step_done
        if done.all():
            break
    elapsed = time.perf_counter() - start
    per_instance_runtime = float(elapsed) / max(len(envs), 1)
    rows: list[dict[str, Any]] = []
    for info in infos:
        row = select_best_trajectory(info, include_routes=include_routes)
        row["runtime_s"] = per_instance_runtime
        row["batch_runtime_s"] = float(elapsed)
        rows.append(row)
    return rows
