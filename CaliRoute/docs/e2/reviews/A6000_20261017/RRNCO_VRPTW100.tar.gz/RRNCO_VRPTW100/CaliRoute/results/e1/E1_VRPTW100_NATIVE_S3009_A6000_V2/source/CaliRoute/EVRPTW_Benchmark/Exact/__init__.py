"""Exact routing benchmarks."""
