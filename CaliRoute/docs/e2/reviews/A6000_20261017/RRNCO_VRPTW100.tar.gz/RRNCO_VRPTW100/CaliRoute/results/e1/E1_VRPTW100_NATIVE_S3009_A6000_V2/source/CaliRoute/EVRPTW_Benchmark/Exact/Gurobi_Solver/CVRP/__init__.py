"""Legacy Gurobi CVRP benchmark."""
