"""Evaluate completed native runs with a recorded metric-serialization fix."""
import hashlib
import json
from pathlib import Path
import sys

driver = Path(__file__).resolve().parent
record = json.loads((driver / 'provenance.json').read_text())
code = Path(record['evaluation_code_root'])

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

for name, expected in record['source_files'].items():
    if sha(code / name) != expected:
        raise ValueError(f'Evaluation driver source changed: {name}')
if sha(Path(record['campaign']) / 'manifest.json') != record['training_manifest_sha256']:
    raise ValueError('Original training manifest changed')
sys.path.insert(0, str(code))
from e1.runner import parser, evaluate, verify_campaign
from e1.lifecycle import assert_accepted_test_result
from e1.evaluation import atomic_json

args = parser().parse_args()
if args.command != 'evaluate' or args.method not in ('rrnco', 'radar'):
    raise ValueError('This driver only evaluates the two completed native methods')
if Path(args.campaign).resolve() != Path(record['campaign']):
    raise ValueError('Evaluation driver belongs to a different campaign')
# Call the versioned evaluator directly: runner.main would re-execute the old
# acceptance checker. evaluate still verifies the original frozen campaign,
# checkpoint ownership/selection, budget, GPU lock, and all 1000 test identities.
evaluate(args)
manifest = verify_campaign(args.campaign)
accepted = assert_accepted_test_result(manifest, args.method)
atomic_json(Path(manifest['methods'][args.method]['run_dir']) / 'test/evaluation_driver.json',
            dict(driver=str(driver), provenance_sha256=sha(driver / 'provenance.json'),
                 entrypoint_sha256=sha(__file__), arguments=sys.argv[1:],
                 accepted=accepted['accepted']))
