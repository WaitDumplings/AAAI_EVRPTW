from __future__ import annotations

from typing import Any

import numpy as np
import torch
import torch.nn as nn

from .nets.graph_model.decoder import Decoder
from .nets.graph_model.embedding import AutoEmbedding
from .nets.graph_model.encoder import GraphAttentionEncoder
from .nets.graph_model.routing_adapters import DirectedEdgeBias
from caliroute.plugins.rdi import RoadDistanceInjection
from caliroute.plugins.input_encoding import PhysicalInputContextAdapter
from caliroute.plugins.physical_static import TypedStaticFusion, DirectedPhysicalRelationEncoder
from caliroute.plugins.joint_graph import JointGraphEncoder


class Problem:
    def __init__(self, name: str):
        self.NAME = name


def _to_tensor(value: Any, device: str | torch.device) -> torch.Tensor:
    if isinstance(value, torch.Tensor):
        return value.to(device)
    return torch.as_tensor(value, device=device)


def prepare_observation_batch(obs: dict[str, Any]) -> dict[str, Any]:
    """Add the outer env-batch dimension when a single EVRPTW env obs is passed."""
    out: dict[str, Any] = {}
    for key, value in obs.items():
        arr = value if isinstance(value, torch.Tensor) else np.asarray(value)
        if key in {
            "cus_loc",
            "rs_loc",
            "time_window",
            "edge_distance",
            "edge_time",
            "edge_energy",
            "action_mask",
            "node_visit_count",
            "customer_visited",
            "cs_visited_current_route",
            "route_membership_current",
            "route_order_rank",
            "node_input_context",
        }:
            out[key] = arr[None, ...] if arr.ndim == 2 else value
        elif key == "graph_input_context":
            out[key] = arr[None, ...] if arr.ndim == 1 else value
        elif key == "depot_loc":
            out[key] = arr[None, ...] if arr.ndim == 2 else value
        elif key in {
            "demand",
            "service_time",
            "last_node_idx",
            "prev_node_idx",
            "current_load",
            "current_battery",
            "remaining_battery",
            "current_time",
        }:
            out[key] = arr[None, ...] if arr.ndim == 1 else value
        elif key in {
            "visited_customers_ratio",
            "visited_customers_raio",
            "remain_feasible_customers_ratio",
            "remain_feasible_customers_raio",
            "route_served_customers_ratio",
            "rs_streak_ratio",
            "current_route_step_count",
            "current_route_customer_count",
        }:
            out[key] = arr[None, ...] if arr.ndim == 2 else value
        elif key in {"battery_capacity", "loading_capacity", "full_charge_time", "fixed_full_charge"}:
            out[key] = arr[None, ...] if arr.ndim == 1 else value
        else:
            out[key] = value
    if "visited_customers_ratio" not in out and "visited_customers_raio" in out:
        out["visited_customers_ratio"] = out["visited_customers_raio"]
    if "visited_customers_raio" not in out and "visited_customers_ratio" in out:
        out["visited_customers_raio"] = out["visited_customers_ratio"]
    if "remain_feasible_customers_ratio" not in out and "remain_feasible_customers_raio" in out:
        out["remain_feasible_customers_ratio"] = out["remain_feasible_customers_raio"]
    if "remain_feasible_customers_raio" not in out and "remain_feasible_customers_ratio" in out:
        out["remain_feasible_customers_raio"] = out["remain_feasible_customers_ratio"]
    return out


def _require_edge_matrix(states: dict[str, torch.Tensor], key: str, expected_nodes: int) -> None:
    value = states.get(key)
    if value is None:
        raise KeyError(
            f"EVRPTW observation is missing {key!r}. "
            "This cleaned branch requires true road-network edge matrices; "
            "falling back to Euclidean coordinate distance would invalidate the true-metric experiments."
        )
    if value.dim() not in (2, 3):
        raise ValueError(f"Expected {key} to have shape [N,N] or [B,N,N], got {tuple(value.shape)}")
    if int(value.size(-1)) != expected_nodes or int(value.size(-2)) != expected_nodes:
        raise ValueError(
            f"{key} shape {tuple(value.shape)} does not match expected node count {expected_nodes} "
            "(depot + customers + charging stations)."
        )


def orthogonal_init(layer: nn.Module, gain: float = 1.0) -> None:
    if isinstance(layer, nn.Linear):
        nn.init.orthogonal_(layer.weight, gain=gain)
        if layer.bias is not None:
            nn.init.zeros_(layer.bias)


class StateWrapper:
    """Adapt EVRPTW-DB Gymnasium observations to the Ablation graph model."""

    def __init__(self, states: dict[str, Any], device: str | torch.device, problem: str = "evrptw"):
        self.device = device
        self.problem = problem
        states = prepare_observation_batch(states)
        self.states = {key: _to_tensor(value, device=device) for key, value in states.items()}
        if problem == "evrptw":
            self._build_evrptw_state()

    @staticmethod
    def _as_node_scalar(value: torch.Tensor) -> torch.Tensor:
        value = value.float()
        if value.dim() == 3 and value.size(-1) == 1:
            return value
        if value.dim() == 2:
            return value.unsqueeze(-1)
        raise ValueError(f"Expected node scalar with shape [B,N] or [B,N,1], got {tuple(value.shape)}")

    def _build_evrptw_state(self) -> None:
        demand = self._as_node_scalar(self.states["demand"])
        service_time = self._as_node_scalar(self.states["service_time"])
        time_window = self.states["time_window"].float()
        expected_nodes = (
            1
            + int(self.states["cus_loc"].size(1))
            + int(self.states["rs_loc"].size(1))
        )
        for key in ("edge_distance", "edge_time", "edge_energy"):
            _require_edge_matrix(self.states, key, expected_nodes)

        observations = {
            "depot_loc": self.states["depot_loc"].float(),
            "cus_loc": self.states["cus_loc"].float(),
            "rs_loc": self.states["rs_loc"].float(),
            "time_window": time_window,
            "demand": demand,
            "service_time": service_time,
        }
        self.states["observations"] = observations
        self.VEHICLE_CAPACITY = self.states["loading_capacity"]
        self.VEHICLE_BATTERY = self.states["battery_capacity"]
        self.used_capacity = self.states["current_load"].float()
        self.used_battery = self.states["current_battery"].float()
        self.current_time = self.states["current_time"].float()
        self.visited_customers_ratio = self.states["visited_customers_ratio"].float()
        self.remain_feasible_customers_ratio = self.states["remain_feasible_customers_ratio"].float()

    @property
    def observations(self) -> dict[str, torch.Tensor]:
        return self.states["observations"]

    def get_current_node(self) -> torch.Tensor:
        return self.states["last_node_idx"].long()

    def get_mask(self) -> torch.Tensor:
        return ~self.states["action_mask"].bool()


class Backbone(nn.Module):
    """Ablation TERRAN-style backbone with graph token and optional DDE."""

    # Encoder inputs are static within an episode and contain no dropout or
    # running-stat normalization; all dynamic route state is read by decode().
    supports_static_rollout_cache = True

    def __init__(
        self,
        embedding_dim: int = 256,
        problem_name: str = "evrptw",
        n_encode_layers: int = 2,
        tanh_clipping: float = 15.0,
        n_heads: int = 16,
        device: str | torch.device = "cpu",
        use_graph_token: bool = True,
        use_dynamic_decision_encoder: bool = False,
        dynamic_decision_heads: int = 4,
        dynamic_decision_delta_k: bool = True,
        dynamic_decision_delta_v: bool = True,
        dynamic_decision_delta_action_key: bool = True,
        dynamic_decision_action_bias: bool = True,
        use_encoder_distance_bias: bool = True,
        use_residual_edge_bias: bool = False,
        residual_edge_hidden_dim: int = 32,
        use_post_charge_adapter: bool = False,
        post_charge_adapter_hidden_dim: int = 32,
        optimize_dynamic_projections: bool = False,
        cache_static_observations: bool = False,
        use_static_rollout_cache: bool = True,
        use_rdi_v2: bool = False,
        rdi_hidden_dim: int = 32,
        use_agda_v2: bool = False,
        agda_hidden_dim: int = 32,
        agda_physical_candidate_features: bool = False,
        agda_smooth_distance_features: bool = False,
        use_encoder_sdpa: bool = False,
        use_physical_input_context: bool = False,
        physical_input_context_hidden_dim: int = 32,
        use_typed_static_fusion: bool = False,
        use_edge_relation_encoder: bool = False,
        edge_relation_dim: int = 16,
        use_edge_value_messages: bool = False,
        use_edge_state_updates: bool = False,
        use_resource_decoder: bool = False,
        use_joint_graph_encoder: bool = False,
        joint_graph_edge_dim: int = 32,
        joint_graph_dropout: float = 0.,
        decoder_observation_mode: str = "feasible",
        e1_base_distance_row: bool = False,
    ):
        super().__init__()
        del use_graph_token  # graph token is intrinsic to the migrated graph encoder.
        self.device = device
        self.problem = Problem(problem_name)
        if (use_typed_static_fusion or use_edge_relation_encoder or use_resource_decoder or use_joint_graph_encoder) and not use_physical_input_context:
            raise ValueError('Stage-2 integration requires use_physical_input_context=True')
        if (use_edge_value_messages or use_edge_state_updates) and not use_edge_relation_encoder:
            raise ValueError('Edge value messages/updates require use_edge_relation_encoder=True')
        if isinstance(edge_relation_dim, bool) or not isinstance(edge_relation_dim, int) or edge_relation_dim < 1:
            raise ValueError('edge_relation_dim must be a positive integer')
        if decoder_observation_mode not in {'feasible', 'dual'}:
            raise ValueError('decoder_observation_mode must be feasible or dual')
        if decoder_observation_mode != 'feasible' and not use_resource_decoder:
            raise ValueError('dual observation requires use_resource_decoder=True')
        self.model_integration_settings = {
            'use_typed_static_fusion': bool(use_typed_static_fusion),
            'use_edge_relation_encoder': bool(use_edge_relation_encoder),
            'edge_relation_dim': int(edge_relation_dim),
            'use_edge_value_messages': bool(use_edge_value_messages),
            'use_edge_state_updates': bool(use_edge_state_updates),
            'use_resource_decoder': bool(use_resource_decoder),
            'decoder_observation_mode': decoder_observation_mode,
            'agda_physical_candidate_features': bool(agda_physical_candidate_features),
            'agda_smooth_distance_features': bool(agda_smooth_distance_features),
        }
        if use_joint_graph_encoder and (use_edge_relation_encoder or use_edge_value_messages or use_edge_state_updates):
            raise ValueError('Joint graph encoder replaces the old edge relation encoder and its value/update switches')
        if use_joint_graph_encoder:
            self.model_integration_settings.update(use_joint_graph_encoder=True,
                joint_graph_edge_dim=joint_graph_edge_dim, joint_graph_dropout=joint_graph_dropout)
        if e1_base_distance_row:
            self.model_integration_settings['e1_base_distance_row'] = True
        self.use_joint_graph_encoder = bool(use_joint_graph_encoder)
        effective_edge_dim = joint_graph_edge_dim if use_joint_graph_encoder else edge_relation_dim
        self.use_encoder_distance_bias = bool(use_encoder_distance_bias)
        self.supports_static_rollout_cache = bool(use_static_rollout_cache)
        self.cache_static_observations = bool(cache_static_observations)
        self.embedding = AutoEmbedding(self.problem.NAME, {"embedding_dim": embedding_dim})
        self.joint_graph_encoder = None
        if use_joint_graph_encoder:
            self.encoder = None
            self.joint_graph_encoder = JointGraphEncoder(
                embedding_dim=embedding_dim, edge_dim=joint_graph_edge_dim,
                n_heads=n_heads, n_layers=n_encode_layers, dropout=joint_graph_dropout)
        else:
            self.encoder = GraphAttentionEncoder(
                n_heads=n_heads,
                embed_dim=embedding_dim,
                n_layers=n_encode_layers,
                use_sdpa=use_encoder_sdpa,
                use_edge_relation_encoder=use_edge_relation_encoder,
                edge_relation_dim=edge_relation_dim,
                use_edge_value_messages=use_edge_value_messages,
                use_edge_state_updates=use_edge_state_updates,
            )
        self.decoder = Decoder(
            embedding_dim=embedding_dim,
            step_context_dim=embedding_dim + 5,
            n_heads=n_heads,
            problem=self.problem,
            tanh_clipping=tanh_clipping,
            use_dynamic_decision_encoder=use_dynamic_decision_encoder,
            dynamic_decision_heads=dynamic_decision_heads,
            dynamic_decision_delta_k=dynamic_decision_delta_k,
            dynamic_decision_delta_v=dynamic_decision_delta_v,
            dynamic_decision_delta_action_key=dynamic_decision_delta_action_key,
            dynamic_decision_action_bias=dynamic_decision_action_bias,
            use_post_charge_adapter=use_post_charge_adapter,
            post_charge_adapter_hidden_dim=post_charge_adapter_hidden_dim,
            optimize_dynamic_projections=optimize_dynamic_projections,
            use_agda_v2=use_agda_v2,
            agda_hidden_dim=agda_hidden_dim,
            agda_physical_candidate_features=agda_physical_candidate_features,
            agda_smooth_distance_features=agda_smooth_distance_features,
            use_resource_decoder=use_resource_decoder,
            decoder_observation_mode=decoder_observation_mode,
            e1_base_distance_row=e1_base_distance_row,
            use_edge_relation_encoder=use_edge_relation_encoder or use_joint_graph_encoder,
            edge_relation_dim=effective_edge_dim,
        )

        self.dist_bias_scale = nn.Parameter(torch.tensor(1.0))
        self.type_pair_bias = nn.Embedding(3 * 3, 1)
        nn.init.zeros_(self.type_pair_bias.weight)
        self.residual_edge_bias = None
        if use_residual_edge_bias:
            # Optional modules must not shift initialization of shared weights.
            with torch.random.fork_rng(devices=[]):
                self.residual_edge_bias = DirectedEdgeBias(n_heads=n_heads, hidden_dim=residual_edge_hidden_dim)

        self.rdi_adapter = None
        if use_rdi_v2:
            if use_residual_edge_bias:
                raise ValueError("use_rdi_v2 replaces use_residual_edge_bias; enable only one")
            with torch.random.fork_rng(devices=[]):
                self.rdi_adapter = RoadDistanceInjection(n_heads=n_heads, hidden_dim=rdi_hidden_dim)

        self.physical_input_adapter = None
        if use_physical_input_context:
            # Keep both existing model initialization and the caller RNG unchanged.
            with torch.random.fork_rng(devices=[]):
                self.physical_input_adapter = PhysicalInputContextAdapter(
                    embedding_dim=embedding_dim,
                    hidden_dim=physical_input_context_hidden_dim,
                )

        self.static_fusion = None
        if use_typed_static_fusion:
            with torch.random.fork_rng(devices=[]):
                self.static_fusion = TypedStaticFusion(embedding_dim)
        self.edge_relation_encoder = None
        if use_edge_relation_encoder or use_joint_graph_encoder:
            with torch.random.fork_rng(devices=[]):
                self.edge_relation_encoder = DirectedPhysicalRelationEncoder(effective_edge_dim)

    def _build_node_type(self, node_inputs: dict[str, torch.Tensor]) -> torch.Tensor:
        depot_loc = node_inputs["depot_loc"]
        batch_size = depot_loc.size(0)
        n_cus = node_inputs["cus_loc"].size(1)
        n_rs = node_inputs["rs_loc"].size(1)
        device = node_inputs["cus_loc"].device
        depot_type = torch.zeros(batch_size, 1, dtype=torch.long, device=device)
        customer_type = torch.full((batch_size, n_cus), 2, dtype=torch.long, device=device)
        station_type = torch.ones(batch_size, n_rs, dtype=torch.long, device=device)
        return torch.cat([depot_type, customer_type, station_type], dim=1)

    def _build_distance_matrix(self, node_inputs: dict[str, torch.Tensor]) -> torch.Tensor:
        depot_loc = node_inputs["depot_loc"]
        if depot_loc.dim() == 2:
            depot_loc = depot_loc.unsqueeze(1)
        nodes = torch.cat([depot_loc, node_inputs["cus_loc"], node_inputs["rs_loc"]], dim=1)
        return torch.cdist(nodes, nodes, p=2)

    def _build_attn_bias(self, state: StateWrapper) -> torch.Tensor:
        node_inputs = state.observations
        dist_mat = state.states.get("edge_distance")
        if dist_mat is None:
            dist_mat = self._build_distance_matrix(node_inputs)
        else:
            dist_mat = dist_mat.to(device=node_inputs["cus_loc"].device, dtype=node_inputs["cus_loc"].dtype)
            if dist_mat.dim() == 2:
                dist_mat = dist_mat.unsqueeze(0)
        node_type = self._build_node_type(node_inputs)
        dist_bias = -self.dist_bias_scale * dist_mat if self.use_encoder_distance_bias else torch.zeros_like(dist_mat)
        pair_id = node_type.unsqueeze(2) * 3 + node_type.unsqueeze(1)
        type_bias = self.type_pair_bias(pair_id).squeeze(-1)
        attn_bias = dist_bias + type_bias
        if self.residual_edge_bias is not None:
            attn_bias = attn_bias.unsqueeze(1) + self.residual_edge_bias(state.states)

        if self.rdi_adapter is not None:
            residual = self.rdi_adapter(
                distance=dist_mat, travel_time=state.states.get("edge_time"),
                energy=state.states.get("edge_energy"), time_windows=state.states.get("time_window"),
                service_time=state.states.get("service_time"),
                battery_capacity=state.states.get("battery_capacity"), base_bias=attn_bias,
            )
            attn_bias = attn_bias.unsqueeze(1) + residual

        edge_energy = state.states.get("edge_energy")
        battery_capacity = state.states.get("battery_capacity")
        if edge_energy is None or battery_capacity is None:
            return attn_bias
        edge_energy = edge_energy.to(device=attn_bias.device, dtype=attn_bias.dtype)
        if edge_energy.dim() == 2:
            edge_energy = edge_energy.unsqueeze(0)
        if edge_energy.size(0) == 1 and attn_bias.size(0) != 1:
            edge_energy = edge_energy.expand(attn_bias.size(0), -1, -1)
        battery_capacity = battery_capacity.to(device=attn_bias.device, dtype=attn_bias.dtype)
        if battery_capacity.dim() == 0:
            battery_capacity = battery_capacity.view(1, 1, 1)
        elif battery_capacity.dim() == 1:
            battery_capacity = battery_capacity.view(-1, 1, 1)
        else:
            battery_capacity = battery_capacity.reshape(battery_capacity.size(0), -1)[:, :1].view(-1, 1, 1)
        if battery_capacity.size(0) == 1 and attn_bias.size(0) != 1:
            battery_capacity = battery_capacity.expand(attn_bias.size(0), -1, -1)
        unreachable = edge_energy > (battery_capacity + 1e-6)
        eye = torch.eye(attn_bias.size(-1), dtype=torch.bool, device=attn_bias.device).unsqueeze(0)
        unreachable = unreachable & ~eye
        if attn_bias.dim() == 4:
            unreachable = unreachable.unsqueeze(1)
        return attn_bias.masked_fill(unreachable, -1e9)

    def _build_joint_attn_bias(self, state, valid):
        """Road prior for representation learning, separate from action feasibility.

        Graph inputs must supply authoritative road D/T/E. Invalid or inactive
        costs are selected out before learned arithmetic; no Euclidean fallback
        or battery-capacity hard mask is used for structural communication.
        """
        states = dict(state.states)
        graph = states['graph_input_context']
        distance = states['edge_distance'].float()
        if distance.ndim == 2:
            distance = distance.unsqueeze(0)
        distance = torch.where(valid, distance, 0.)
        states['edge_distance'] = distance
        for key, flag in (('edge_time', 8), ('edge_energy', 6)):
            value = states[key].float()
            if value.ndim == 2:
                value = value.unsqueeze(0)
            states[key] = torch.where(valid & (graph[:, None, None, flag] > .5), value, 0.)
        for key in ('time_window', 'service_time'):
            value = states[key]
            active = (graph[:, 8] > .5).reshape(-1, *([1] * (value.ndim - 1)))
            states[key] = torch.where(active, value, 0.)
        capacity = states['battery_capacity']
        active = (graph[:, 6] > .5).reshape(-1, *([1] * (capacity.ndim - 1)))
        states['battery_capacity'] = torch.where(active, capacity, torch.ones_like(capacity))
        node_type = self._build_node_type(state.observations)
        pair_id = node_type.unsqueeze(2) * 3 + node_type.unsqueeze(1)
        bias = self.type_pair_bias(pair_id).squeeze(-1)
        if self.use_encoder_distance_bias:
            bias = bias - self.dist_bias_scale * distance
        if self.residual_edge_bias is not None:
            bias = bias.unsqueeze(1) + self.residual_edge_bias(states)
        if self.rdi_adapter is not None:
            bias = bias.unsqueeze(1) + self.rdi_adapter(distance=distance,
                travel_time=states['edge_time'], energy=states['edge_energy'],
                time_windows=states['time_window'], service_time=states['service_time'],
                battery_capacity=states['battery_capacity'], base_bias=bias)
        return bias

    def _build_state(self, obs: dict[str, Any]) -> StateWrapper:
        return StateWrapper(obs, device=self.device, problem=self.problem.NAME)

    def _encode_from_state(self, state: StateWrapper, use_mask: bool = False):
        node_mask = state.states.get("instance_mask") if use_mask else None
        if node_mask is not None:
            node_mask = node_mask.bool()
        node_embeddings = self.embedding(state.observations)
        if self.physical_input_adapter is not None:
            for key in ("node_input_context", "graph_input_context"):
                if key not in state.states:
                    raise KeyError(
                        f"Physical input context is enabled, but observation is missing {key!r}. "
                        "Use the matching physical input normalization schema."
                    )
            node_context = state.states["node_input_context"]
            if node_context.ndim != 3 or node_context.shape[:2] != node_embeddings.shape[:2]:
                raise ValueError(
                    "node_input_context batch/node dimensions must match embeddings "
                    f"{tuple(node_embeddings.shape[:2])}, got {tuple(node_context.shape)}"
                )
            node_embeddings = node_embeddings + self.physical_input_adapter(
                node_context, state.states["graph_input_context"]
            )
        graph_context = None
        if self.static_fusion is not None:
            node_embeddings, graph_context = self.static_fusion(
                node_embeddings, state.observations, state.states, self._build_node_type(state.observations)
            )
        edge_relations = edge_valid = None
        if self.edge_relation_encoder is not None:
            edge_relations, edge_valid = self.edge_relation_encoder(
                state.states, self._build_node_type(state.observations)
            )
        if self.joint_graph_encoder is not None:
            encoded_nodes, edge_relations = self.joint_graph_encoder(
                node_embeddings, edge_relations, edge_valid, state.states['graph_input_context'],
                node_mask=node_mask, graph_context=graph_context,
                attn_bias=self._build_joint_attn_bias(state, edge_valid))
        else:
            encoded_nodes, edge_relations = self.encoder(
                node_embeddings,
                mask=None,
                attn_bias=self._build_attn_bias(state),
                graph_context=graph_context,
                edge_relations=edge_relations,
                return_edge_relations=True,
            )
        cached = self.decoder._precompute(encoded_nodes, mask=node_mask)
        if edge_relations is not None:
            auxiliary = dict(cached[5]) if len(cached) > 5 else {}
            auxiliary['edge_relations'] = edge_relations
            auxiliary['edge_relation_valid'] = edge_valid
            cached = (*cached[:5], auxiliary)
        if self.cache_static_observations:
            static_keys = {
                "cus_loc", "depot_loc", "rs_loc", "demand", "time_window", "service_time",
                "edge_distance", "edge_time", "edge_energy", "battery_capacity", "loading_capacity",
                "full_charge_time", "fixed_full_charge",
                "node_input_context", "graph_input_context",
            }
            auxiliary = dict(cached[5]) if len(cached) > 5 else {}
            auxiliary["static_state"] = {key: state.states[key] for key in static_keys if key in state.states}
            cached = (*cached[:5], auxiliary)
        return cached, node_mask

    def forward(self, obs: dict[str, Any], use_mask: bool = False):
        state = self._build_state(obs)
        cached_embeddings, node_mask = self._encode_from_state(state, use_mask=use_mask)
        logits, glimpse = self.decoder.advance(cached_embeddings, state, node_mask=node_mask)
        return logits, glimpse

    def encode(self, obs: dict[str, Any], use_mask: bool = False):
        state = self._build_state(obs)
        cached_embeddings, _ = self._encode_from_state(state, use_mask=use_mask)
        return cached_embeddings

    def decode(self, obs: dict[str, Any], cached_embeddings, use_mask: bool = False):
        if len(cached_embeddings) > 5 and "static_state" in cached_embeddings[5]:
            obs = {**obs, **cached_embeddings[5]["static_state"]}
        state = self._build_state(obs)
        node_mask = state.states.get("instance_mask") if use_mask else None
        if node_mask is not None:
            node_mask = node_mask.bool()
        return self.decoder.advance(cached_embeddings, state, node_mask=node_mask)


class Actor(nn.Module):
    def forward(self, backbone_output):
        return backbone_output[0]


class Critic(nn.Module):
    def __init__(self, hidden_size: int, use_decomposed_critic: bool = False):
        super().__init__()
        self.use_decomposed_critic = bool(use_decomposed_critic)
        self.trunk = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.LayerNorm(hidden_size),
            nn.SiLU(),
            nn.Linear(hidden_size, hidden_size // 2),
            nn.SiLU(),
        )
        out_dim = 3 if self.use_decomposed_critic else 1
        self.head = nn.Linear(hidden_size // 2, out_dim)
        for layer in self.trunk:
            orthogonal_init(layer, gain=0.01)
        orthogonal_init(self.head, gain=0.01)

    def forward(self, backbone_output):
        value = self.head(self.trunk(backbone_output[1]))
        normalizer = getattr(self, "_value_normalizer", None)
        return normalizer.denormalize(value) if normalizer is not None else value


class Agent(nn.Module):
    def __init__(
        self,
        embedding_dim: int = 256,
        tanh_clipping: float = 15.0,
        n_encode_layers: int = 2,
        device: str | torch.device = "cpu",
        name: str = "evrptw",
        use_graph_token: bool = True,
        use_dynamic_decision_encoder: bool = False,
        dynamic_decision_heads: int = 4,
        dynamic_decision_delta_k: bool = True,
        dynamic_decision_delta_v: bool = True,
        dynamic_decision_delta_action_key: bool = True,
        dynamic_decision_action_bias: bool = True,
        use_encoder_distance_bias: bool = True,
        use_residual_edge_bias: bool = False,
        residual_edge_hidden_dim: int = 32,
        use_post_charge_adapter: bool = False,
        post_charge_adapter_hidden_dim: int = 32,
        optimize_dynamic_projections: bool = False,
        cache_static_observations: bool = False,
        use_static_rollout_cache: bool = True,
        use_rdi_v2: bool = False,
        rdi_hidden_dim: int = 32,
        use_agda_v2: bool = False,
        agda_hidden_dim: int = 32,
        agda_physical_candidate_features: bool = False,
        agda_smooth_distance_features: bool = False,
        use_encoder_sdpa: bool = False,
        use_decomposed_critic: bool = False,
        use_physical_input_context: bool = False,
        physical_input_context_hidden_dim: int = 32,
        use_typed_static_fusion: bool = False,
        use_edge_relation_encoder: bool = False,
        edge_relation_dim: int = 16,
        use_edge_value_messages: bool = False,
        use_edge_state_updates: bool = False,
        use_resource_decoder: bool = False,
        use_joint_graph_encoder: bool = False,
        joint_graph_edge_dim: int = 32,
        joint_graph_dropout: float = 0.,
        decoder_observation_mode: str = "feasible",
        e1_base_distance_row: bool = False,
    ):
        super().__init__()
        self.embedding_dim = int(embedding_dim)
        self.backbone = Backbone(
            embedding_dim=embedding_dim,
            device=device,
            tanh_clipping=tanh_clipping,
            n_encode_layers=n_encode_layers,
            problem_name=name,
            use_graph_token=use_graph_token,
            use_dynamic_decision_encoder=use_dynamic_decision_encoder,
            dynamic_decision_heads=dynamic_decision_heads,
            dynamic_decision_delta_k=dynamic_decision_delta_k,
            dynamic_decision_delta_v=dynamic_decision_delta_v,
            dynamic_decision_delta_action_key=dynamic_decision_delta_action_key,
            dynamic_decision_action_bias=dynamic_decision_action_bias,
            use_encoder_distance_bias=use_encoder_distance_bias,
            use_residual_edge_bias=use_residual_edge_bias,
            residual_edge_hidden_dim=residual_edge_hidden_dim,
            use_post_charge_adapter=use_post_charge_adapter,
            post_charge_adapter_hidden_dim=post_charge_adapter_hidden_dim,
            optimize_dynamic_projections=optimize_dynamic_projections,
            cache_static_observations=cache_static_observations,
            use_static_rollout_cache=use_static_rollout_cache,
            use_rdi_v2=use_rdi_v2,
            rdi_hidden_dim=rdi_hidden_dim,
            use_agda_v2=use_agda_v2,
            agda_hidden_dim=agda_hidden_dim,
            agda_physical_candidate_features=agda_physical_candidate_features,
            agda_smooth_distance_features=agda_smooth_distance_features,
            use_encoder_sdpa=use_encoder_sdpa,
            use_physical_input_context=use_physical_input_context,
            physical_input_context_hidden_dim=physical_input_context_hidden_dim,
            use_typed_static_fusion=use_typed_static_fusion,
            use_edge_relation_encoder=use_edge_relation_encoder,
            edge_relation_dim=edge_relation_dim,
            use_edge_value_messages=use_edge_value_messages,
            use_edge_state_updates=use_edge_state_updates,
            use_resource_decoder=use_resource_decoder,
            use_joint_graph_encoder=use_joint_graph_encoder,
            joint_graph_edge_dim=joint_graph_edge_dim,
            joint_graph_dropout=joint_graph_dropout,
            decoder_observation_mode=decoder_observation_mode,
            e1_base_distance_row=e1_base_distance_row,
        )
        self.actor = Actor()
        self.critic = Critic(hidden_size=embedding_dim, use_decomposed_critic=use_decomposed_critic)
        self.partition_head = nn.Sequential(
            nn.LayerNorm(4 * embedding_dim),
            nn.Linear(4 * embedding_dim, embedding_dim),
            nn.SiLU(),
            nn.Linear(embedding_dim, 1),
        )
        for layer in self.partition_head:
            orthogonal_init(layer, gain=0.01)

    def forward(self, x, use_mask: bool = False, return_logits: bool = True):
        backbone_output = self.backbone(x, use_mask=use_mask)
        logits = self.actor(backbone_output)
        action = logits.max(2)[1]
        if not return_logits:
            return action
        return action, logits

    def get_value(self, x, use_mask: bool = False):
        return self.critic(self.backbone(x, use_mask=use_mask))

    def get_action_and_value(self, x, action=None, use_mask: bool = False):
        backbone_output = self.backbone(x, use_mask=use_mask)
        logits = self.actor(backbone_output)
        probs = torch.distributions.Categorical(logits=logits)
        if action is None:
            action = probs.sample()
        return action, probs.log_prob(action), probs.entropy(), self.critic(backbone_output)

    def get_acction_and_value(self, x, action=None, use_mask: bool = False):
        return self.get_action_and_value(x, action=action, use_mask=use_mask)

    def get_value_cached(self, x, state):
        return self.critic(self.backbone.decode(x, state))

    def get_action_and_value_cached(self, x, action=None, state=None, cached_embeddings=None, print_probs: bool = False):
        del print_probs
        if cached_embeddings is None:
            cached_embeddings = state
        if cached_embeddings is None:
            cached_embeddings = self.backbone.encode(x)
        backbone_output = self.backbone.decode(x, cached_embeddings)
        logits = self.actor(backbone_output)
        probs = torch.distributions.Categorical(logits=logits)
        if action is None:
            action = probs.sample()
        return action, probs.log_prob(action), probs.entropy(), self.critic(backbone_output), cached_embeddings

    def partition_logits(self, x, use_mask: bool = False):
        state = self.backbone._build_state(x)
        cached_embeddings, _ = self.backbone._encode_from_state(state, use_mask=use_mask)
        node_embeddings = cached_embeddings[0]
        n_customers = int(state.states["cus_loc"].size(1))
        customer_embeddings = node_embeddings[:, 1 : 1 + n_customers, :]
        left = customer_embeddings.unsqueeze(2).expand(-1, -1, n_customers, -1)
        right = customer_embeddings.unsqueeze(1).expand(-1, n_customers, -1, -1)
        pair_features = torch.cat([left, right, torch.abs(left - right), left * right], dim=-1)
        logits = self.partition_head(pair_features).squeeze(-1)
        return 0.5 * (logits + logits.transpose(1, 2))
